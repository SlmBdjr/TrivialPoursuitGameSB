
console.log("Trivial Pursuit Game Loaded!");
// Ajoutez votre logique de jeu ici
    